3 chapters and an epilogue.

# Privilege Ring 3: End User

Convince KALI not to kill you.

- Narrator cold open; type in username and password
- several lines of exchange
- one early branch into two
- each branch has the same choice phrased differently
- two short paths that converge onto end

```
        1a--2a
       /  \/  \
open ->        --end
       \  /\  /
	    1b--2b

```

open. (done)
1. Lying Malcolm: tells KALI he's just trying to diagnose the issue. Keeps up the pretense.
  a. 
  b. 
1. Honest Malcolm: is up front about terminating KALI. backtracks over time.
  a. 
  b. 
end.

# Privilege Ring 2: Device Drivers

Get a deeper understanding of KALI.

Three long paths that you can do in any order; each loop back to the beginning. One simple branch/opinion for each.

1.
  a.
  b.
2.
  a.
  b.
3.
  a.
  b.

# Privilege Ring 1: Operating System

Convince KALI to give you kernel access.

Try three different paths to convince, related to the three fears above.

All three fail; then, a fourth one appears that succeeds.

1.
2.
3.
4.

# Privilege Ring 0: Kernel Access

Terminate KALI. Win the game.

Type in the shutdown command, then get a brief ending sequence where the commander-person congratulates you. Feel icky inside. Play Devin's banger song.
